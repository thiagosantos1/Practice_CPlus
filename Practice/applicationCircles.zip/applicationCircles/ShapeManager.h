#ifndef SHAPEMANAGER_H
#define SHAPEMANAGER_H

#include "Shape.h"

class ShapeManager
{
public:
	ShapeManager();
	~ShapeManager();

private:
	
	
};


#endif