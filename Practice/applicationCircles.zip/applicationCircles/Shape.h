#ifndef SHAPE_H
#define SHAPE_H 

#include <SFML/Graphics.hpp>

class Shape{
public:

	Shape();

	Shape(float x, float y, float radius);

	void draw(sf::RenderWindow & window) const;

	void setVelocity(float vx, float vy);

	void move(float seconds, const sf::RenderWindow & window);

	void setPosition(float x, float y);

	void setRadius(int r);


private:

	bool checkWalls(const sf::RenderWindow & window);
	sf::CircleShape circle;

	// measure velocity in pixels per second
	float velocity_x;
	float velocity_y;

};


#endif