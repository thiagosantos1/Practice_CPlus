#include <cstdlib>
#include <iostream>
#include <cmath>
#include <SFML/Graphics.hpp> 
#include <ctime>


#include "Shape.h"
#include "ShapeManager.h"

using std::cout;
using std::endl;

int main(){

    std::srand(std::time(0));

    sf::RenderWindow window(sf::VideoMode(1200, 700), "Bouncing Windown");

    const int num_shapes = 2;
    Shape shapes[num_shapes];

    for (int i = 0; i < num_shapes; i++)
    {
        // generate random parameters
        int shape_width = rand() % 40 + 10;
        float x = rand() % (window.getSize().x - shape_width);
        float y = rand() % (window.getSize().y - shape_width);
        float vx = rand() % 400 -200;
        float vy = rand() % 400 -200;

        // set randomly generated parameters
        shapes[i].setRadius(shape_width /2);
        shapes[i].setPosition(x,y);
        shapes[i].setVelocity(vx,vy);


    }

    //s.setVelocity(100,100);

    sf::Clock clock;

      while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        sf::Time elapsedTime = clock.restart();

        for (int i = 0; i < num_shapes; i++)
        {
            shapes[i].move(elapsedTime.asSeconds(), window);
        }

        for (int i = 0; i < num_shapes; i++)
        {
            shapes[i].draw(window);
        }

        window.clear();
        //s.draw(window);
        //s.move(elapsedTime.asSeconds(), window);


        window.display();
    }
    
    return 0;
}