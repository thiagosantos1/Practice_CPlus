#include "Shape.h" 
#include <iostream>
#include <cstdlib>
#include <cmath>

Shape::Shape()
	: circle(0),
	 velocity_x(0), 
	 velocity_y(0)

{
	circle.setPosition(0,0);
	
}


Shape::Shape(float x, float y, float radius)
	: circle(radius),
	  velocity_x (0),
	  velocity_y (0)
{
	circle.setPosition(x,y);
	
}

void Shape::draw(sf::RenderWindow & window) const
{

	window.draw(circle);
}

void Shape::setVelocity(float vx, float vy){

	velocity_x = vx;
	velocity_y = vy;
}

void Shape::setPosition(float x, float y){

	circle.setPosition(x,y);
}
	
void Shape::setRadius(int r){

	circle.setRadius(r);
}

void Shape::move(float seconds, const sf::RenderWindow & window){

	checkWalls(window);

	float current_x = circle.getPosition().x;
	float current_y = circle.getPosition().y;

	float next_x = current_x + seconds * velocity_x;
	float next_y = current_y + seconds * velocity_y;

	circle.setPosition(next_x,next_y);
}

bool Shape::checkWalls(const sf::RenderWindow & window){

	bool hit_a_wall =false;

	float top = circle.getPosition().y;

	if(top < 0){
		velocity_y = std::abs(velocity_y);
		hit_a_wall = true;
	}

	float left = circle.getPosition().x;
	if (left<0)		
	{
		velocity_x = std::abs(velocity_x);
		hit_a_wall = true;
	}

	float bottom = top + circle.getGlobalBounds().height;

	if( bottom > window.getSize().y ){
		velocity_y = - std::abs(velocity_y);
		hit_a_wall = true;
	}

	float right = left + circle.getGlobalBounds().width;
	if (right >  window.getSize().x )		
	{
		velocity_x = -std::abs(velocity_x);
		hit_a_wall = true;
	}

	return hit_a_wall;


}








